//::$lib/devTools/1.0.1/core.js::
//::$lib/toLocale/1.2.0/core.js::
//::$lib/whichType/1.0.1/core.js::
//::$lib/AlaSQLonGAS/1.7.2/alasql.min.js::

//::$src/config.js::
const dev = devTools();
const db = SpreadDB(cf);

//::$src/onOpen.js::
//::$src/concatYFP.js::
//::$src/createReport.js::
//::$src/getFileList.js::
//::$src/mergePDFs.js::
//::$src/refreshFiles.js::
//::$src/refreshMaster.js::
//::$src/SpreadDB.js::
//::$src/utilities.js::