# AlaSQL internal help system

* HELP keyword