
AlaSQL is based on unpaid voluntary work. Thank you for taking the time to make it better. 

Question about how to ...
- Please use http://stackoverflow.com/questions/ask?tags=alasql

Something is not working as expected:
- Describe the problem  
- Provide code that replicates the problem 
- We suggest to spawn a jsfiddle from http://jsfiddle.net/98qL7m0c/

