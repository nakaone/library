INSERT INTO one(a,b) VALUES (1,'Ten');
INSERT INTO one(a,b) VALUES (2,'Twenty');
INSERT INTO one(a,b) VALUES (3,'Val''s Deser');
