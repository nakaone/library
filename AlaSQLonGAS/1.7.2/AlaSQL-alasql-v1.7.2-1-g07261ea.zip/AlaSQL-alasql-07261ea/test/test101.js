if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 101 - Oracle, MySQL, MSSQL, SQLite, Postgress mode', function () {
	//	it.skip('localStorage', function(done){
	//		done();
	//	});
});
