if (typeof exports === 'object') {
	var assert = require('assert');
	var alasql = require('..');
}

describe('Test 102 - Execution Plan', function () {
	//	it.skip('localStorage', function(done){
	//		done();
	//	});
});
