
<a name="authResponse"></a>

authServerからauthClientに送られる処理結果オブジェクト

| No | 項目名 | 任意 | データ型 | 既定値 | 説明 |
| --: | :-- | :--: | :-- | :-- | :-- |
| 1 | requestId | ❌ | string | — | 要求の識別子。UUID |
| 2 | timestamp | ❌ | number | — | 処理日時。UNIX時刻 |
| 3 | result | ❌ | string | — | 処理結果。decryptRequst.result |
| 4 | message | ❌ | string | — | エラーメッセージ。decryptRequest.message |
| 5 | response | ❌ | string|Object | — | 要求された関数の戻り値をJSON化した文字列。適宜オブジェクトのまま返す。 |
