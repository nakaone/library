
<a name="authIndexedDB"></a>

- クライアントのIndexedDBに保存するオブジェクト
- IndexedDB保存時のキー名は`authConfig.system.name`から取得

| No | 項目名 | 任意 | データ型 | 既定値 | 説明 |
| --: | :-- | :--: | :-- | :-- | :-- |
| 1 | keyGeneratedDateTime | ❌ | number | — | 鍵ペア生成日時。UNIX時刻(new Date().getTime()),なおサーバ側でCPkey更新中にクライアント側で新たなCPkeyが生成されるのを避けるため、鍵ペア生成は30分以上の間隔を置く。 |
| 2 | memberId | ❌ | string | — | メンバの識別子(=メールアドレス) |
| 3 | profile | ❌ | Object | — | メンバの属性 |
| 4 | profile.memberName | ❌ | string | — | メンバ(ユーザ)の氏名(ex."田中　太郎")。加入要求確認時に管理者が申請者を識別する他で使用。 |
| 5 | CSkeySign | ❌ | CryptoKey | — | 署名用秘密鍵 |
| 6 | CPkeySign | ❌ | CryptoKey | — | 署名用公開鍵 |
| 7 | CSkeyEnc | ❌ | CryptoKey | — | 暗号化用秘密鍵 |
| 8 | CPkeyEnc | ❌ | CryptoKey | — | 暗号化用公開鍵 |
| 9 | SPkey | ❌ | string | — | サーバ公開鍵(Base64) |
| 10 | ApplicationForMembership | ⭕ | number | -1 | 加入申請実行日時。未申請時は-1 |
| 11 | expireAccount | ⭕ | number | -1 | 加入承認の有効期間が切れる日時。未加入時は-1 |
| 12 | expireCPkey | ⭕ | number | -1 | CPkeyの有効期限。未ログイン時は-1 |
