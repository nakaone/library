/**
 * @typedef {Object} decryptedRequest - decryptRequestで復号された処理要求オブジェクト
 * @prop {string} result - 処理結果。"fatal"(後続処理不要なエラー), "warning"(後続処理が必要なエラー), "success"
 * @prop {string} message - エラーメッセージ
 * @prop {string|Object} detail - 詳細情報。ログイン試行した場合、その結果
 * @prop {authRequest} request - ユーザから渡された処理要求
 * @prop {string} timestamp - 復号処理実施日時。メール・ログでの閲覧が容易になるよう、文字列で保存
 */