
<a name="encryptedRequest"></a>

authClientからauthServerに渡す暗号化された処理要求オブジェクト

| No | 項目名 | 任意 | データ型 | 既定値 | 説明 |
| --: | :-- | :--: | :-- | :-- | :-- |
| 1 | memberId | ❌ | string | — | メンバの識別子(=メールアドレス) |
| 2 | ciphertext | ❌ | string | — | 暗号化された文字列 |
