/**
 * @typedef {Object} encryptedRequest - authClientからauthServerに渡す暗号化された処理要求オブジェクト
 * @prop {string} memberId - メンバの識別子(=メールアドレス)
 * @prop {string} ciphertext - 暗号化された文字列
 */