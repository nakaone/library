/**
 * @typedef {Object} MemberProfile - メンバの属性情報(Member.profile)
 * @prop {string} 
 */