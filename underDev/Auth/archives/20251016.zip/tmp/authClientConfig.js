/**
 * @typedef {Object} authClientConfig - authConfigを継承した、authClientでのみ使用する設定値
 * @prop {string} x - サーバ側WebアプリURLのID(`https://script.google.com/macros/s/(この部分)/exec`)
 * @prop {number} [timeout=300000] - サーバからの応答待機時間。これを超えた場合はサーバ側でfatalとなったと解釈する。既定値は5分
 */