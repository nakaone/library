
<a name="authIndexedDB"></a>

- クライアントのIndexedDBに保存するオブジェクト
- IndexedDB保存時のキー名は`authConfig.system.name`から取得

| No | 項目名 | 任意 | データ型 | 既定値 | 説明 |
| --: | :-- | :--: | :-- | :-- | :-- |
| 1 | keyGeneratedDateTime | ❌ | number | — | 鍵ペア生成日時。UNIX時刻(new Date().getTime()),なおサーバ側でCPkey更新中にクライアント側で新たなCPkeyが生成されるのを避けるため、鍵ペア生成は30分以上の間隔を置く。 |
| 2 | memberId | ❌ | string | — | メンバの識別子(=メールアドレス) |
| 3 | memberName | ❌ | string | — | メンバ(ユーザ)の氏名(ex."田中　太郎")。加入要求確認時に管理者が申請者を識別する他で使用。 |
| 4 | CSkeySign | ❌ | CryptoKey | — | 署名用秘密鍵 |
| 5 | CPkeySign | ❌ | CryptoKey | — | 署名用公開鍵 |
| 6 | CSkeyEnc | ❌ | CryptoKey | — | 暗号化用秘密鍵 |
| 7 | CPkeyEnc | ❌ | CryptoKey | — | 暗号化用公開鍵 |
| 8 | SPkey | ❌ | string | — | サーバ公開鍵(Base64) |
| 9 | ApplicationForMembership | ❌ | number | — | 加入申請実行日時。未申請時は0 |
| 10 | expireAccount | ❌ | number | — | 加入承認の有効期間が切れる日時。未加入時は0 |
| 11 | expireCPkey | ❌ | number | — | CPkeyの有効期限。未ログイン時は0 |
