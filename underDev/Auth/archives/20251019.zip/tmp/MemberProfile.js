/**
 * @typedef {Object} MemberProfile - メンバの属性情報(Member.profile)
 * @prop {number} [authority=1] - メンバの持つ権限。authServerConfig.func.authorityとの論理積>0なら当該関数実行権限ありと看做す
 */