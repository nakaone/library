/**
 * @typedef {Object} MemberDevice - メンバが使用する通信機器の情報(マルチデバイス対応)
 * @prop {string} deviceId - デバイスの識別子。UUID
 * @prop {string} [status="未認証"] - デバイスの状態。未認証,認証中,試行中,凍結中
 * @prop {string} CPkey - メンバの公開鍵
 * @prop {number} CPkeyUpdated - 最新のCPkeyが登録された日時
 * @prop {string} trial - ログイン試行関連情報オブジェクト(MemberTrial[])。シート保存時はJSON文字列
 */