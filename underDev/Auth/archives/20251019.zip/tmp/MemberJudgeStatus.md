
<a name="MemberJudgeStatus"></a>

Memeber.judgeStatusメソッドの戻り値

| No | 項目名 | 任意 | データ型 | 既定値 | 説明 |
| --: | :-- | :--: | :-- | :-- | :-- |
| 1 | memberId | ❌ | string |  | メンバの識別子(=メールアドレス) |
| 2 | status | ❌ | string |  | Member.deviceが空ならメンバの、空で無ければデバイスのstatus |
| 3 | memberStatus | ❌ | string |  | メンバの状態。未加入,未審査,審査済,加入中,加入禁止 |
| 4 | deviceId | ⭕ | string |  | デバイスの識別子。UUID |
| 5 | deviceStatus | ⭕ | string |  | デバイスの状態。未認証,認証中,試行中,凍結中 |
