/**
 * @typedef {Object} authClientConfig - authConfigを継承した、authClientで使用する設定値
 * @prop {string} x - サーバ側WebアプリURLのID(`https://script.google.com/macros/s/(この部分)/exec`)
 */