/**
 * @typedef {Object} authServerConfig - authConfigを継承した、authServerで使用する設定値
 * @prop {string} [memberList="memberList"] - memberListシート名
 * @prop {number} defaultAuthority=0 - 新規加入メンバの権限の既定値
 * @prop {number} [memberLifeTime=31536000000] - メンバ加入承認後の有効期間。既定値：1年
 * @prop {number} [loginLifeTime=86400000] - ログイン成功後の有効期間(=CPkeyの有効期間)。既定値：1日
 * @prop {Object.<string,Object>} func - サーバ側の関数マップ
 * @prop {number} func.authority - 当該関数実行のために必要となるユーザ権限,`Member.profile.authority & authServerConfig.func.authrity > 0`なら実行可とする。
 * @prop {Function|Arrow} func.do - 実行するサーバ側関数
 * @prop {Object} trial - ログイン試行関係の設定値
 * @prop {number} [trial.passcodeLength=6] - パスコードの桁数
 * @prop {number} [trial.freezing=3600000] - 連続失敗した場合の凍結期間。既定値：1時間
 * @prop {number} [trial.maxTrial=3] - パスコード入力の最大試行回数
 * @prop {number} [trial.passcodeLifeTime=600000] - パスコードの有効期間。既定値：10分
 * @prop {number} [trial.generationMax=5] - ログイン試行履歴(MemberTrial)の最大保持数。既定値：5世代
 */