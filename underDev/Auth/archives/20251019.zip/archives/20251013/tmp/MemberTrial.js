/**
 * @typedef {Object} MemberTrial - ログイン試行単位の試行情報(Member.trial)
 * @prop {string} passcode - 設定されているパスコード
 * @prop {number} created - パスコード生成日時(≒パスコード通知メール発信日時)
 * @prop {number} freezingUntil=0 - 凍結解除日時。最大試行回数を超えたら現在日時を設定
 * @prop {number} CPkeyUpdateUntil=0 - CPkey更新処理中の場合、更新期限をUNIX時刻でセット
 * @prop {MemberTrialLog[]} [log] - 試行履歴。常に最新が先頭(unshift()使用)
 */