/**
 * @typedef {Object} authResponse - authServerからauthClientに送られる処理結果オブジェクト
 * @prop {string} requestId - 要求の識別子。UUID
 * @prop {number} timestamp - 処理日時。UNIX時刻
 * @prop {string} result - 処理結果。decryptRequst.result
 * @prop {string} message - エラーメッセージ。decryptRequest.message
 * @prop {string|Object} response - 要求された関数の戻り値をJSON化した文字列。適宜オブジェクトのまま返す。
 */