
<a name="authServerConfig"></a>

authConfigを継承した、authServerで使用する設定値

| No | 項目名 | 任意 | データ型 | 既定値 | 説明 |
| --: | :-- | :--: | :-- | :-- | :-- |
| 1 | memberList | ⭕ | string | memberList | memberListシート名 |
| 2 | defaultAuthority | ❌ | number | — | 新規加入メンバの権限の既定値 |
| 3 | memberLifeTime | ⭕ | number | 31536000000 | メンバ加入承認後の有効期間。既定値：1年 |
| 4 | loginLifeTime | ⭕ | number | 86400000 | ログイン成功後の有効期間(=CPkeyの有効期間)。既定値：1日 |
| 5 | func | ❌ | Object.<string,Object> | — | サーバ側の関数マップ |
| 6 | func.authority | ❌ | number | — | 当該関数実行のために必要となるユーザ権限,`Member.profile.authority & authServerConfig.func.authrity > 0`なら実行可とする。 |
| 7 | func.do | ❌ | Function|Arrow | — | 実行するサーバ側関数 |
| 8 | trial | ❌ | Object | — | ログイン試行関係の設定値 |
| 9 | trial.passcodeLength | ⭕ | number | 6 | パスコードの桁数 |
| 10 | trial.freezing | ⭕ | number | 3600000 | 連続失敗した場合の凍結期間。既定値：1時間 |
| 11 | trial.maxTrial | ⭕ | number | 3 | パスコード入力の最大試行回数 |
| 12 | trial.passcodeLifeTime | ⭕ | number | 600000 | パスコードの有効期間。既定値：10分 |
| 13 | trial.generationMax | ⭕ | number | 5 | ログイン試行履歴(MemberTrial)の最大保持数。既定値：5世代 |
