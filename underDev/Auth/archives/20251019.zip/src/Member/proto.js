class Member {
  //::$src/Member/constructor.js::
  //::$src/Member/getAllMembers.js::
  //::$src/Member/getMember.js::
  //::$src/Member/judgeStatus.js::
  //::$src/Member/setMember.js::
}