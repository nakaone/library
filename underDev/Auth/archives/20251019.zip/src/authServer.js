//::$src/authServer/core.js::
//::$src/Member/core.js::
