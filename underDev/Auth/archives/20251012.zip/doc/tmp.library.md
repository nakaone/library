
---

# ライブラリ

以下はソースまで作成済、稼働実績のある自作関数。

## createPassword

```js
//::$lib/createPassword/1.0.1/core.js::
```

## sendMail

```js
//::$lib/sendMail/1.0.0/core.js::
```

## SpreadDb

```js
//::$lib/SpreadDb/2.2.0/core.js::
```

## Schema

```js
//::$lib/Schema/1.2.0/core.js::
```

## toLocale

```js
//::$lib/SpreadDb/1.2.0/core.js::
```

## whichType

```js
//::$lib/whichType/1.0.1/core.js::
```

## devTools

グローバル領域の先頭で`const dev = devTools()`を宣言の上、使用

```js
//::$lib/devTools/1.0.1/core.js::
```
