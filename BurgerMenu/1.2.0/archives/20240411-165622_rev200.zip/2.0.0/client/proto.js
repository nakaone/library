/**
 * @classdesc htmlソースからdata-BurgerMenu属性を持つ要素を抽出、表示内容の権限の存否に従ってハンバーガーメニューを作成
 */
class BurgerMenu {
//::methods_add_here::
}