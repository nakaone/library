/** サーバ側固有の設定情報 */
const config = {
  name: 'authServer', // プロパティサービスに保存する際のラベル
  RSA:{
    bits: 2048,  // ビット長
    passphrase: 'HkI/yP~TeU&Qcd<6IjL6-X96MhH7LJag',
    publicKey: null, // 公開鍵
    privateKey: null, // 秘密鍵
  },
};
