class authClient {
  //:x:$src/authClient.constructor.js::
  //:x:$src/authClient.registMail.js::
  //:x:$src/authClient.login1C.js::
  //:x:$src/authClient.login2C.js::
}