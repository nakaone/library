/** 単一スプレッドシートまたはデータオブジェクト配列のCRUDを行う
 * - [仕様書](https://workflowy.com/#/91d73fc35411)
 */
class SingleTable {
  //::$src/constructor.js::
  //::$src/insertSheet.js::
  //::$src/objectizeNote.js::
  //::$src/append.js::
}