# SpreadDb rev.1.1.0

## 概要

## 引数

## 戻り値

rv {Object[]} 以下のメンバを持つオブジェクトの配列
<!--::$doc/SpreadDb.rv.md::-->
