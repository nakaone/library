/*
  SpreadDbテスト用ソース
    GASの専用シートを用意、本ソースをコピペしてSpreadDbTest()を実行する
*/

//::$src/test.core.js::

//::$prj/core.js::

//::$lib/isEqual/1.1.0/core.js::
//::$lib/mergeDeeply/1.1.0/core.js::
//::$lib/stringify/1.1.1/core.js::
//::$lib/toLocale/1.1.0/core.js::
//::$lib/vlog/1.1.0/core.js::
//::$lib/whichType/1.0.1/core.js::