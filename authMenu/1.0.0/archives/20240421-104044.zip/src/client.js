class authMenu {
  //::$src/client.constructor.js::
  //::$src/client.setProperties.js::

  // ===================================
  // メニュー関係(旧BurgerMenu)
  // ===================================
  //::$src/menu.objectize.js::
  //::$src/menu.genNavi.js::

}