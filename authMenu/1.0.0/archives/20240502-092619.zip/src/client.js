class authMenu {
  //::$src/client.constructor.js::
  //::$src/client.setProperties.js::
  //::$src/client.storeUserInfo.js::
  //::$src/client.utilities.js::
  //::$src/client.changeScreen.js::

  // ===================================
  // メニュー関係(旧BurgerMenu)
  // ===================================
  //::$src/menu.objectize.js::
  //::$src/menu.genNavi.js::

  // ===================================
  // 認証関係(旧Auth)
  // ===================================
  //::$src/auth.registMail.js::
}