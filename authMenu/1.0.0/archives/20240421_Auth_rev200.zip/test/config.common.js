const g = {programId:'camp2024'};
