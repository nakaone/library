class authClient {
  //::$src/client.constructor.js::

  // setUserInfo, doGAS
  //::$src/client.utilities.js::

  //::$src/client.registMail.js::
  //:x:$src/client.login1C.js::
  //:x:$src/client.login2C.js::
}
