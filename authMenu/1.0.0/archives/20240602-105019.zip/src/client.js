class authMenu {
  //::$src/client.constructor.js::
  //::$src/client.changeScreen.js::
  //::$src/client.genNavi.js::
  //::$src/client.objectize.js::
  //::$src/client.setProperties.js::
  //::$src/client.storeUserInfo.js::
  //::$src/client.utilities.js::
}